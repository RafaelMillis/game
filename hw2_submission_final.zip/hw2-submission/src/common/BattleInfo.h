//
// Created by amit on 5/27/25.
//

#ifndef TANKSBATTLEGAME_BATTLEINFO_H
#define TANKSBATTLEGAME_BATTLEINFO_H

class BattleInfo {
public:
    virtual ~BattleInfo() {}
};

#endif //TANKSBATTLEGAME_BATTLEINFO_H
