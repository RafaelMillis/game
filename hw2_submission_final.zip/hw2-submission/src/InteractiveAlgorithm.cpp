#include "InteractiveAlgorithm.h"

// All implementation is in the header file 